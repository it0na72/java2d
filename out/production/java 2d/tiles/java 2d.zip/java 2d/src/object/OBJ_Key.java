package object;
import entity.entity;

public class OBJ_Key extends entity {

    public OBJ_Key(main.panel panel) {
        super(panel);

        name = "Key";
        down1 = setup("/objects/key");
        }
    }
